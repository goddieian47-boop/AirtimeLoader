package com.example.airtimeloader

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Detects candidate codes from WhatsApp notifications; it NEVER redeems automatically. */
class PinListenerService : NotificationListenerService() {
    private companion object {
        val WHATSAPP = setOf("com.whatsapp", "com.whatsapp.w4b")
        val PIN = Regex("""(?<!\d)(\d{4})[ \u00A0-]?(\d{4})[ \u00A0-]?(\d{4})[ \u00A0-]?(\d{4})(?!\d)""")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in WHATSAPP) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = listOfNotNull(
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString("\n")
        ).joinToString("\n")
        val combined = "$title\n$text"
        // Avoid collecting unrelated WhatsApp numbers: notification must mention Safaricom or airtime.
        if (!combined.contains("safaricom", true) && !combined.contains("airtime", true)) return
        val codes = PIN.findAll(combined).map { it.groupValues.drop(1).joinToString("") }.distinct().toList()
        if (codes.isNotEmpty()) Store.addCandidates(this, codes)
    }
}
