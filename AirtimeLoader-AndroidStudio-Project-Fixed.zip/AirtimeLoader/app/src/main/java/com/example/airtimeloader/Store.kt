package com.example.airtimeloader

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local-only storage for discovered codes, attempted codes and a short activity log. */
object Store {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("airtime_loader", Context.MODE_PRIVATE)

    fun candidates(ctx: Context): Set<String> = prefs(ctx).getStringSet("candidates", emptySet()).orEmpty().toSet()
    fun addCandidates(ctx: Context, codes: Collection<String>) {
        val set = candidates(ctx).toMutableSet()
        set.addAll(codes.filter { it.length == 16 && it.all(Char::isDigit) && !wasTried(ctx, it) })
        prefs(ctx).edit().putStringSet("candidates", set).apply()
        if (codes.isNotEmpty()) log(ctx, "Detected ${codes.size} possible code(s); review before redeeming.")
    }
    fun removeCandidate(ctx: Context, code: String) {
        val set = candidates(ctx).toMutableSet(); set.remove(code)
        prefs(ctx).edit().putStringSet("candidates", set).apply()
    }
    fun wasTried(ctx: Context, code: String): Boolean = prefs(ctx).getStringSet("tried", emptySet()).orEmpty().contains(code)
    fun markTried(ctx: Context, code: String) {
        val set = prefs(ctx).getStringSet("tried", emptySet()).orEmpty().toMutableSet(); set.add(code)
        prefs(ctx).edit().putStringSet("tried", set).apply()
        removeCandidate(ctx, code)
    }
    fun log(ctx: Context, line: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val old = prefs(ctx).getString("log", "").orEmpty().lines()
        val lines = (listOf("$stamp  $line") + old).filter { it.isNotBlank() }.take(40)
        prefs(ctx).edit().putString("log", lines.joinToString("\n")).apply()
    }
    fun readLog(ctx: Context): String = prefs(ctx).getString("log", "").orEmpty()
    fun clearLog(ctx: Context) { prefs(ctx).edit().remove("log").apply() }
}
