package com.example.airtimeloader

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.telephony.TelephonyManager
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private lateinit var column: LinearLayout
    private val pad by lazy { (16 * resources.displayMetrics.density).toInt() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        column.addView(TextView(this).apply {
            text = "Airtime Loader\n\nFinds possible 16-digit codes in relevant WhatsApp notifications. Nothing is redeemed automatically. Review each code and confirm before sending a USSD request."
            textSize = 17f
        })
        addButton("1. Enable notification access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        addButton("2. Allow phone permission") {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), 101)
        }
        addButton("Refresh detected codes") { render() }
        addButton("Clear activity log") { Store.clearLog(this); render() }
        setContentView(ScrollView(this).apply { addView(column) })
        render()
    }

    override fun onResume() { super.onResume(); if (::column.isInitialized) render() }

    private fun addButton(label: String, action: () -> Unit) {
        column.addView(Button(this).apply { text = label; setOnClickListener { action() } })
    }

    private fun render() {
        if (!::column.isInitialized) return
        while (column.childCount > 5) column.removeViewAt(5)
        column.addView(TextView(this).apply { text = "\nDetected codes awaiting review (${Store.candidates(this@MainActivity).size})"; textSize = 18f })
        Store.candidates(this).sorted().forEach { code ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = code.chunked(4).joinToString(" "); textSize = 16f }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply { text = "Review / redeem"; setOnClickListener { confirmRedeem(code) } })
            column.addView(row)
        }
        column.addView(TextView(this).apply { text = "\nRecent activity\n${Store.readLog(this@MainActivity).ifEmpty { "No activity yet." }}" })
    }

    private fun confirmRedeem(code: String) {
        AlertDialog.Builder(this)
            .setTitle("Redeem this code?")
            .setMessage("Code: ${code.chunked(4).joinToString(" ")}\n\nThis sends *141*$code# through your phone's selected SIM. Continue only if this is a genuine Safaricom giveaway voucher and you want to try it.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Send USSD") { _, _ -> sendUssd(code) }
            .show()
    }

    private fun sendUssd(code: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            Store.log(this, "Not sent: phone permission not granted")
            render(); return
        }
        try {
            val tm = getSystemService(TelephonyManager::class.java)
            if (tm == null) { Store.log(this, "Not sent: telephony service unavailable"); render(); return }
            tm.sendUssdRequest("*141*$code#", object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(t: TelephonyManager, request: String, response: CharSequence) {
                    Store.markTried(this@MainActivity, code)
                    Store.log(this@MainActivity, "…${code.takeLast(4)}: ${response.toString().replace('\n', ' ').take(160)}")
                    runOnUiThread { AlertDialog.Builder(this@MainActivity).setTitle("Safaricom response").setMessage(response.toString()).setPositiveButton("OK", null).show(); render() }
                }
                override fun onReceiveUssdResponseFailed(t: TelephonyManager, request: String, failureCode: Int) {
                    Store.log(this@MainActivity, "…${code.takeLast(4)}: USSD request failed ($failureCode)")
                    runOnUiThread { AlertDialog.Builder(this@MainActivity).setTitle("USSD request failed").setMessage("Android/SIM returned error code $failureCode. The code was not marked as successfully redeemed.").setPositiveButton("OK", null).show(); render() }
                }
            }, android.os.Handler(mainLooper))
        } catch (e: Exception) {
            Store.log(this, "…${code.takeLast(4)}: ${e.javaClass.simpleName}")
            render()
        }
    }
}
